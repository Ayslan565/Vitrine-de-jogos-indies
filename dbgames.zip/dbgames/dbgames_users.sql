-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dbgames
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('player','developer') DEFAULT 'player',
  `bio` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'dev_studio_alpha','alpha@dev.com','hash_falso_123','developer','Estúdio focado em jogos de ação.','2026-05-26 14:21:22'),(2,'indie_br','contato@indiebr.com','hash_falso_123','developer','Desenvolvedor solo do Brasil.','2026-05-26 14:21:22'),(3,'pixel_masters','pixel@masters.com','hash_falso_123','developer','Amamos pixel art e jogos retrô.','2026-05-26 14:21:22'),(4,'rpg_legends','rpg@legends.com','hash_falso_123','developer','Criadores de mundos imersivos.','2026-05-26 14:21:22'),(5,'vr_innovators','vr@innovators.com','hash_falso_123','developer','Pioneiros em realidade virtual.','2026-05-26 14:21:22'),(6,'strategy_core','core@strategy.com','hash_falso_123','developer','Táticas e estratégia em tempo real.','2026-05-26 14:21:22'),(7,'horror_tales','scare@horror.com','hash_falso_123','developer','Especialistas em sustos e mistérios.','2026-05-26 14:21:22'),(8,'casual_fun','fun@casual.com','hash_falso_123','developer','Jogos relaxantes para o dia a dia.','2026-05-26 14:21:22'),(9,'esports_forge','comp@esports.com','hash_falso_123','developer','Focados no cenário competitivo.','2026-05-26 14:21:22'),(10,'narrative_arts','arts@narrative.com','hash_falso_123','developer','Contadores de histórias interativas.','2026-05-26 14:21:22'),(11,'pro_gamer99','progamer@email.com','hash_falso_123','player','Sempre em busca da platina.','2026-05-26 14:21:22'),(12,'casual_carl','carl@email.com','hash_falso_123','player','Jogo apenas nos finais de semana.','2026-05-26 14:21:22'),(13,'rpg_fanatic','rpgfan@email.com','hash_falso_123','player','Adoro explorar masmorras.','2026-05-26 14:21:22'),(14,'speedrunner_x','speed@email.com','hash_falso_123','player','Termino jogos em tempo recorde.','2026-05-26 14:21:22'),(15,'noob_master','noob@email.com','hash_falso_123','player','Ainda aprendendo a jogar.','2026-05-26 14:21:22'),(16,'tactics_guy','tactics@email.com','hash_falso_123','player','Penso antes de agir.','2026-05-26 14:21:22'),(17,'horror_lover','dark@email.com','hash_falso_123','player','Nada me assusta.','2026-05-26 14:21:22'),(18,'coop_friend','coop@email.com','hash_falso_123','player','Sempre jogo com a galera.','2026-05-26 14:21:22'),(19,'indie_supporter','indielover@email.com','hash_falso_123','player','Apoio pequenos estúdios.','2026-05-26 14:21:22'),(20,'retro_player','retro@email.com','hash_falso_123','player','Saudades dos anos 90.','2026-05-26 14:21:22');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-26 11:23:43
