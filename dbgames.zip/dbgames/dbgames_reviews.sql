-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dbgames
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `game_id` int NOT NULL,
  `user_id` int NOT NULL,
  `notas` int DEFAULT NULL,
  `comentario` text NOT NULL,
  `tempo_criado` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `game_id` (`game_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_chk_1` CHECK (((`notas` >= 1) and (`notas` <= 5)))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (1,7,13,5,'Melhor RPG que já joguei na minha vida! 100 horas fáceis.','2026-05-26 14:21:22'),(2,7,11,4,'Muito bom, mas os gráficos poderiam ser melhores.','2026-05-26 14:21:22'),(3,17,11,5,'Perfeito para o competitivo, jogo todo dia.','2026-05-26 14:21:22'),(4,17,15,2,'Comunidade muito tóxica com quem está aprendendo.','2026-05-26 14:21:22'),(5,13,17,5,'Tomei muitos sustos, recomendo demais!','2026-05-26 14:21:22'),(6,13,12,3,'É assustador, mas os controles são travados.','2026-05-26 14:21:22'),(7,3,19,5,'Indie nacional de altíssima qualidade, parabéns!','2026-05-26 14:21:22'),(8,21,14,4,'Ótimo para speedrun, mecânicas bem precisas.','2026-05-26 14:21:22'),(9,12,16,5,'Estratégia pura e ainda por cima é de graça.','2026-05-26 14:21:22'),(10,10,12,4,'Divertido, mas me deu um pouco de enjoo no VR.','2026-05-26 14:21:22'),(11,1,18,5,'Joguei com meus amigos e rimos bastante.','2026-05-26 14:21:22'),(12,15,20,5,'Muito relaxante para jogar depois do trabalho.','2026-05-26 14:21:22'),(13,8,13,4,'Sistema de magia é incrível, faltou mais chefões.','2026-05-26 14:21:22'),(14,19,16,5,'A história me prendeu do início ao fim.','2026-05-26 14:21:22'),(15,6,20,4,'Bateu uma nostalgia muito forte, mas é meio curto.','2026-05-26 14:21:22');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-26 11:23:44
