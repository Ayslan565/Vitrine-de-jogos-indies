-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dbgames
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `games` (
  `id` int NOT NULL AUTO_INCREMENT,
  `developer_id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `preco` decimal(10,2) DEFAULT '0.00',
  `url` varchar(255) NOT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `developer_id` (`developer_id`),
  CONSTRAINT `games_ibfk_1` FOREIGN KEY (`developer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `games`
--

LOCK TABLES `games` WRITE;
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
INSERT INTO `games` VALUES (1,1,'Guerra Espacial','Um shooter frenético no espaço.',49.99,'http://games.com/guerra-espacial','guerra.jpg','2026-05-26 14:21:22'),(2,1,'Combate Final','Lute até o fim neste jogo de luta.',29.90,'http://games.com/combate-final','combate.jpg','2026-05-26 14:21:22'),(3,2,'Aventura do Jeca','Um jogo de plataforma bem brasileiro.',15.00,'http://games.com/jeca','jeca.jpg','2026-05-26 14:21:22'),(4,2,'Caipira Simulator','Administre sua fazenda.',20.00,'http://games.com/caipira','caipira.jpg','2026-05-26 14:21:22'),(5,3,'Dungeon Pixel','Explore cavernas geradas proceduralmente.',10.50,'http://games.com/dungeon','dungeon.jpg','2026-05-26 14:21:22'),(6,3,'Retro Racers','Corridas clássicas em 8-bits.',5.00,'http://games.com/retro','retro.jpg','2026-05-26 14:21:22'),(7,4,'Reino Caído','Um RPG épico de 100 horas.',99.99,'http://games.com/reino-caido','reino.jpg','2026-05-26 14:21:22'),(8,4,'Magia Sombria','Aprenda magias e derrote dragões.',79.90,'http://games.com/magia','magia.jpg','2026-05-26 14:21:22'),(9,5,'VR Experiência','Simulador de montanha russa em VR.',19.99,'http://games.com/vr-exp','vr.jpg','2026-05-26 14:21:22'),(10,5,'Cozinha VR','Seja um chef de cozinha virtual.',25.00,'http://games.com/cozinha-vr','cozinha.jpg','2026-05-26 14:21:22'),(11,6,'Império Galáctico','Domine planetas com sua frota.',59.90,'http://games.com/imperio','imperio.jpg','2026-05-26 14:21:22'),(12,6,'Defesa de Torres','Proteja sua base dos invasores.',0.00,'http://games.com/defesa','defesa.jpg','2026-05-26 14:21:22'),(13,7,'A Mansão','Fuja antes que seja tarde.',35.00,'http://games.com/mansao','mansao.jpg','2026-05-26 14:21:22'),(14,7,'Sobrevivência Zumbi','Recursos escassos e muitos zumbis.',45.00,'http://games.com/zumbi','zumbi.jpg','2026-05-26 14:21:22'),(15,8,'Quebra-cabeça Zen','Relaxe montando imagens bonitas.',9.99,'http://games.com/zen','zen.jpg','2026-05-26 14:21:22'),(16,8,'Gatos Escondidos','Encontre os gatinhos na tela.',4.99,'http://games.com/gatos','gatos.jpg','2026-05-26 14:21:22'),(17,9,'Arena Competitiva','MOBA 5v5 focado em e-sports.',0.00,'http://games.com/arena','arena.jpg','2026-05-26 14:21:22'),(18,9,'Atirador Tático','Comunicação é a chave da vitória.',0.00,'http://games.com/atirador','atirador.jpg','2026-05-26 14:21:22'),(19,10,'A Escolha','Suas decisões mudam o final.',39.90,'http://games.com/escolha','escolha.jpg','2026-05-26 14:21:22'),(20,10,'Romance na Cidade','Visual novel interativa.',19.90,'http://games.com/romance','romance.jpg','2026-05-26 14:21:22'),(21,2,'Pulo do Gato','Jogo indie de precisão.',12.50,'http://games.com/pulo','pulo.jpg','2026-05-26 14:21:22');
/*!40000 ALTER TABLE `games` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-26 11:23:44
